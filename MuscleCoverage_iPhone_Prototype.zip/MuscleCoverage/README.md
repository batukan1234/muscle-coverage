# MuscleCoverage — iPhone SwiftUI prototype

Bu proje SwiftUI ile hazırlanmış bir iPhone prototipidir.
Xcode'da yeni bir iOS App oluşturup `MuscleCoverageApp.swift` içeriğini kullanabilir
veya bu dosyaları mevcut SwiftUI projesine ekleyebilirsin.

Özellikler:
- Kas grubu seçimi
- Hareket ekleme
- Hareketlerin hedef kas başlarına katkısı
- Kas kapsama yüzdesi
- Eksik bölgeler
- Hareket ekleme önerisi
- Örnek: Triceps Pushdown + Overhead Triceps Extension = triceps başlarının tamamına kapsama

Not: Yüzdeler bilimsel EMG ölçümü değildir; uygulama içindeki ağırlıklı kapsama modelidir.
