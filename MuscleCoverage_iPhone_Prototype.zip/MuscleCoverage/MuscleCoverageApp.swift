import SwiftUI

@main
struct MuscleCoverageApp: App {
    var body: some Scene {
        WindowGroup { ContentView() }
    }
}

struct Exercise: Identifiable, Hashable {
    let id = UUID()
    let name: String
    let group: String
    let targets: [String: Double]
}

let exercises = [
    Exercise(name: "Triceps Pushdown", group: "Triceps",
             targets: ["Lateral baş": 0.75, "Medial baş": 0.65, "Uzun baş": 0.30]),
    Exercise(name: "Overhead Triceps Extension", group: "Triceps",
             targets: ["Lateral baş": 0.45, "Medial baş": 0.55, "Uzun baş": 1.00]),
    Exercise(name: "Close-Grip Bench Press", group: "Triceps",
             targets: ["Lateral baş": 0.65, "Medial baş": 0.75, "Uzun baş": 0.45]),
    Exercise(name: "Incline Dumbbell Press", group: "Göğüs",
             targets: ["Üst göğüs": 0.95, "Orta göğüs": 0.60, "Alt göğüs": 0.20]),
    Exercise(name: "Chest Press", group: "Göğüs",
             targets: ["Üst göğüs": 0.55, "Orta göğüs": 0.95, "Alt göğüs": 0.50]),
    Exercise(name: "Pec Deck", group: "Göğüs",
             targets: ["Üst göğüs": 0.55, "Orta göğüs": 0.90, "Alt göğüs": 0.55]),
    Exercise(name: "Shoulder Press", group: "Omuz",
             targets: ["Ön omuz": 0.95, "Yan omuz": 0.55, "Arka omuz": 0.20]),
    Exercise(name: "Lateral Raise", group: "Omuz",
             targets: ["Ön omuz": 0.20, "Yan omuz": 1.00, "Arka omuz": 0.25]),
    Exercise(name: "Rear Delt Fly", group: "Omuz",
             targets: ["Ön omuz": 0.05, "Yan omuz": 0.30, "Arka omuz": 1.00]),
    Exercise(name: "Hammer Curl", group: "Biceps",
             targets: ["Biceps": 0.65, "Brachialis": 0.90, "Brachioradialis": 0.85]),
    Exercise(name: "Preacher Curl", group: "Biceps",
             targets: ["Biceps": 0.95, "Brachialis": 0.55, "Brachioradialis": 0.30])
]

struct ContentView: View {
    @State private var selectedGroup = "Triceps"
    @State private var selected: [Exercise] = []

    var groupExercises: [Exercise] {
        exercises.filter { $0.group == selectedGroup }
    }

    var subMuscles: [String] {
        Array(Set(groupExercises.flatMap { $0.targets.keys })).sorted()
    }

    func coverage(for muscle: String) -> Double {
        // Diminishing returns: multiple exercises combine without exceeding 100%.
        let remaining = selected.reduce(1.0) { result, ex in
            result * (1 - (ex.targets[muscle] ?? 0))
        }
        return min(1, 1 - remaining)
    }

    var overall: Int {
        guard !subMuscles.isEmpty else { return 0 }
        return Int((subMuscles.map(coverage(for:)).reduce(0,+) / Double(subMuscles.count) * 100).rounded())
    }

    var missing: [String] {
        subMuscles.filter { coverage(for: $0) < 0.75 }
    }

    var suggestion: Exercise? {
        groupExercises
            .filter { !selected.contains($0) }
            .sorted {
                let gain1 = subMuscles.reduce(0) { $0 + max(0, ($1.targets[$0] ?? 0) - coverage(for: $1)) }
                let gain2 = subMuscles.reduce(0) { $0 + max(0, ($1.targets[$0] ?? 0) - coverage(for: $1)) }
                return gain1 > gain2
            }.first
    }

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: 18) {
                    Picker("Kas", selection: $selectedGroup) {
                        ForEach(["Triceps","Göğüs","Omuz","Biceps"], id: \.self) { Text($0) }
                    }
                    .pickerStyle(.segmented)
                    .onChange(of: selectedGroup) { _, _ in selected.removeAll() }

                    ZStack {
                        Circle().stroke(.gray.opacity(0.18), lineWidth: 18)
                        Circle()
                            .trim(from: 0, to: CGFloat(overall)/100)
                            .stroke(.blue, style: StrokeStyle(lineWidth: 18, lineCap: .round))
                            .rotationEffect(.degrees(-90))
                        VStack {
                            Text("%\(overall)")
                                .font(.system(size: 42, weight: .bold))
                            Text("kas kapsaması")
                                .foregroundStyle(.secondary)
                        }
                    }
                    .frame(width: 180, height: 180)

                    VStack(alignment: .leading, spacing: 10) {
                        Text("Bölgeler").font(.title3.bold())
                        ForEach(subMuscles, id: \.self) { muscle in
                            HStack {
                                Text(muscle)
                                Spacer()
                                Text("%\(Int((coverage(for: muscle)*100).rounded()))")
                                    .bold()
                            }
                            ProgressView(value: coverage(for: muscle))
                        }
                    }
                    .padding()
                    .background(.thinMaterial)
                    .clipShape(RoundedRectangle(cornerRadius: 18))

                    if !missing.isEmpty {
                        VStack(alignment: .leading, spacing: 8) {
                            Label("Eksik bölgeler", systemImage: "exclamationmark.triangle.fill")
                                .font(.headline)
                            Text(missing.joined(separator: " • "))
                            if let s = suggestion {
                                Button {
                                    selected.append(s)
                                } label: {
                                    Text("Önerilen hareket: \(s.name)")
                                        .frame(maxWidth: .infinity)
                                }
                                .buttonStyle(.borderedProminent)
                            }
                        }
                        .padding()
                        .background(Color.orange.opacity(0.12))
                        .clipShape(RoundedRectangle(cornerRadius: 18))
                    } else if !selected.isEmpty {
                        Label("Bu kas grubunun tüm alt bölgeleri iyi kapsanıyor.",
                              systemImage: "checkmark.circle.fill")
                            .foregroundStyle(.green)
                            .font(.headline)
                    }

                    VStack(alignment: .leading, spacing: 10) {
                        Text("Hareket ekle").font(.title3.bold())
                        ForEach(groupExercises) { ex in
                            Button {
                                if let index = selected.firstIndex(of: ex) {
                                    selected.remove(at: index)
                                } else {
                                    selected.append(ex)
                                }
                            } label: {
                                HStack {
                                    Image(systemName: selected.contains(ex) ? "checkmark.circle.fill" : "circle")
                                    Text(ex.name)
                                    Spacer()
                                }
                                .padding()
                                .background(.ultraThinMaterial)
                                .clipShape(RoundedRectangle(cornerRadius: 14))
                            }
                            .foregroundStyle(.primary)
                        }
                    }
                }
                .padding()
            }
            .navigationTitle("Muscle Coverage")
        }
    }
}
